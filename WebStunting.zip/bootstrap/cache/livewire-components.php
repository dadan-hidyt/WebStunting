<?php return array (
  'form-input-pengukuran' => 'App\\Http\\Livewire\\FormInputPengukuran',
  'form-kabupaten-kota' => 'App\\Http\\Livewire\\FormKabupatenKota',
  'form-kecamatan' => 'App\\Http\\Livewire\\FormKecamatan',
  'form-kelurahan-desa' => 'App\\Http\\Livewire\\FormKelurahanDesa',
  'form-login' => 'App\\Http\\Livewire\\FormLogin',
  'form-orang-tua' => 'App\\Http\\Livewire\\FormOrangTua',
  'form-posyandu' => 'App\\Http\\Livewire\\FormPosyandu',
  'form-tambah-balita' => 'App\\Http\\Livewire\\FormTambahBalita',
  'form-update-balita' => 'App\\Http\\Livewire\\FormUpdateBalita',
);